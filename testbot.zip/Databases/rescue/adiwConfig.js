module.exports = {
    approval: {
        num: "6285693403858", // Nomor yang diizinkan untuk menyetujui script
        text: "setujui", // Kata kunci untuk menyetujui script
        set: "ANDA HARUS MENDAPATKAN PERSETUJUAN OLEH PUTZZ",
        greet: "ANDA TELAH BERHASIL DI SETUJUI SILAHKAN GUNAKAN SEBAIK MUNGKIN"
    },
    creatorScript: '6285693403858', // Jangan Hapus Ini
    filePath: './approval', // Path untuk file approval
    checkFilePath: './anyaforger.js', // Path untuk file yang dicek integritasnya dan juga itu sesuai kan dengan case milik kalian yak
    codeToDetect: `main();` // Kode yang dicek integritasnya
};
