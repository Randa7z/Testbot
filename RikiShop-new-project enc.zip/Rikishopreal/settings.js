const fs = require('fs');
const chalk = require('chalk');

/*
 
 # Script Ini Tidak Dibagikan Secarq Gratis!! No Enc ? Beli Di Developernya :)
 
 
 # Contact Developer
  * WhatsApp : 6285775414552
  * Telegram : t.me/Rikishop_x_hosting

  
 # Thanks To My Support
  * All Creator Bot WhatsApp
  * AI GPT Chat
  * 𝐑𝐈𝐊𝐈 𝐒𝐇𝐎𝐏

*/

//~~~~~~~~~< GLOBAL SETTINGS >~~~~~~~~~\\

global.owner = ['6285775414552', '6285891142486']
global.ownerUtama = "6285775414552"
global.namaOwner = "RIKI SHOP"
global.packname = 'Bot WhatsApp'
global.botname = 'CPANEL-SIMPEL'
global.botname2 = 'CPANEL-SIMPEL'
global.tempatDB = 'database.json'
global.pairing_code = true
//==============================================
global.linkOwner = "https://wa.me/6285775414552"
global.linkGrup = "https://linktr.ee/rikishopreal"
global.linkGrup2 = "https://chat.whatsapp.com/DTjCb9mJrOQ0bOVIljiFKQ"
global.linkSaluran = "https://whatsapp.com/channel/0029VadvvgF6rsQljgBc7D1t"
global.idChannel = "120363315322575871@newsletter"
global.nameChannel = "TESTIMONI YT : RIKI SHOP [ Testimoni ]"
global.linkytb = 'youtube.com/@RikiShop-x-hosting'
global.sosmed = 'https://linktr.ee/rikishopreal'
//==============================================
// Delay Jpm & Pushctc || 1000 = 1detik
global.delayJpm = 3500
global.delayPushkontak = 6000
//==============================================
// Settings Api Panel Pterodactyl
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "_"
global.apikey = "_" //ptla
global.capikey = "_" //ptlc
//==============================================
global.dana = "085819066475"
global.ovo = "085775414552"
global.gopay = "081400337353"
global.qris = "https://telegra.ph/file/04424a604335ab88e5707.jpg"

// Settings Api Subdomain
global.subdomain = {
"marketrikishop.my.id": {
"zone": "33970794e3373167a9c9556ad19fdb6a", 
"apitoken": "TWf7dzMAu1dOc0XNuE98auJiSryxkUkQBbJpkwgr"
}
}

global.mess = {
	owner: "  \`</> [ Owner Only! ]\`\n- Fitur Ini Hanya Untuk Ownerbot!",
	admin: "  \`</> [ Admin Only! ]\`\n- Fitur Ini Hanya Untuk Admin!",
	botAdmin: "  \`</> [ Bot Admin! ]\`\n- Bot Bukan Admin!",
	group: "  \`</> [ Group Only! ]\`\n- Fitur Ini Hanya Untuk Dalam Grup!",
	private: "  \`</> [ Private Only! ]\`\n- Fitur Ini Hanya Untuk Private Chat!",
	prem: "  \`</> [ Premium Only! ]\`\n- Fitur Ini Hanya Untuk Pengguna Premium!",
	wait: 'Loading...',
	error: 'Error!',
	done: 'Done'
}
//~~~~~~~~~~~~~~~< PROCESS >~~~~~~~~~~~~~~~\\

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});