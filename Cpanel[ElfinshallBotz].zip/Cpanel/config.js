const fs = require('fs')

global.d = new Date()
global.calender = d.toLocaleDateString('id')

//General Settings 
global.prefa = ['','!','.',',','🐤','🗿']
global.ownNumb = '62xxxx' //ganti nomor lu (jangan lupa ganti nomor owner juga di folder "dtbs")
global.NamaOwner = 'Elfinshall' //gausah diganti 
global.sessionName = 'ElfinshallxBotz'
global.namabot = 'ElfinshallBotz' //ganti aj klo mau
global.author = 'Elfinshall' //ganti aj klo mau
global.packname = 'ElfinshallProject' //ganti aj klo mau
global.yt = 'https://youtube.com/@Elfinshall' //gausah diganti 
global.socialm = "https://t.me/Elfinshall" //bebas mau ganti atau engga
global.location = "Indonesia" //bebas mau ganti atau engga

//Payment Setting
global.dana = '08xxx' // Isi No Dana Lu
global.gopay = '08xxx' // Isi No Gopay Lu
global.ovo = '08xxx' // Isi No Ovo Lu
//Tambahin Foto Qr Lu Di Folder "Qris" Dan Ubah Namanya Jadi "qr.jpg"\\

//Panel Settings
global.domain = '_' // isi dengan domain panel lu
global.apikey = '_' // Isi Apikey Plta Lu
global.capikey = '_' // Isi Apikey Pltc Lu
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location


global.mess = { // bagian ini gausah diganti 
    ingroup: '*Fitur ini khusus untuk group*',
    owner: '*Fitur ini khusus owner*',
    premium: '*Fitur ini khusus reseller*',
    usingsetpp: '*Setpp hanya bisa dipake owner*',
    wait: '*Sedang proses*'
}
    
global.autOwn = 'req(62-8S57547ms11).287p'
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
	require('fs').unwatchFile(file)
	console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
	delete require.cache[file]
	require(file)
})